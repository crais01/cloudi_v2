variable = "chris"

puts variable

variable = 20

puts variable