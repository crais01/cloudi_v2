#IO == entrada y salida(input/output)
#print : no agrega un salto de linea

print "ingresa tu nombre : "
nombre = gets.chomp

#nombre = nombre.chomp

puts "hola #{nombre}"

puts "tu #{nombre} tiene tiene #{nombre.length} letras"

