tutor = {
	"nombre"=>"christopher",
	"apellido"=>"cortes",
	"edad"=>29
}

# tutor["cursos"]=10

# puts tutor["cursos"]
# puts tutor

tutor.each do |clave,valor|
	puts "En #{clave} esta guardado #{valor}"
end