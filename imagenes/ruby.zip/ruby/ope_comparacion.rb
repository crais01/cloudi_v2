puts 10 > 5
puts 4 > 5
puts 5 > 5
puts 5 <= 5
puts 5.eql?(8)