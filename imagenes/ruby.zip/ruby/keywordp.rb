def hola(nombre:"",edad:0,**opcion)
	if edad > 30
		puts "Hola señor #{nombre}"
	elsif edad < 30
		puts "Hola joven #{nombre}"
	end
	
	# ** se envia como un hash
	puts opcion[:color_favorito]
end

hola(nombre:"chris",edad:20,color_favorito:"azul",anime_favorito:"dxd")
hola(edad:50,nombre:"cata")
