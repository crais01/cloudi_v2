x = 10
y = 5

puts x+y
puts x-y
puts x*y
puts x/y
puts x**y
puts x%y

puts

numero = gets.chomp
numero = numero.to_i
residuo = numero % 2

if residuo == 0 
	puts "#{numero} es par"
end