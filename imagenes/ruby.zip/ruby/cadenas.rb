#encoding : UTF-8
mensaje = "hola "

nombre = "christopher"

puts mensaje+nombre+"lá"
