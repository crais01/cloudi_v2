require "matrix"
#cantidad de dimenciones : 2
arreglo = [1,2,3,4,5,[1,2,3]]

#arreglos internos, deben tener la misma cantidad de elementos

arrelo = [[1,2,3],[1,2,3]]

# Matrix => todos los elementos deben ser numeros

matriz = Matrix[[1,2,3],[1,2,3],[1,2,3]]
#puts matriz

matriz.each(:diagonal) do |i|
	puts i
end
#elementos por debajo de la diagonal
matriz.each(:strict_lower) do |i|
	puts i
end
#elementos por encima de la diagonal
matriz.each(:strict_upper) do |i|
	puts i
end


