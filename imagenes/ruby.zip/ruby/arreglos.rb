arreglo = [5,"perro",9]

#arreglo_dos = Array.new(5)

puts arreglo
#puts arreglo_dos

arreglo_tres = %w[4 "carro" 50]

arreglo_tres << "holas"

puts arreglo_tres
