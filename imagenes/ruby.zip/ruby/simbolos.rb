#cadena inmutable

cadena = "chris"
cadena2 = "chris"

simbolo = :chris
simbolo2 = :chris

puts cadena.object_id
puts cadena2.object_id

puts simbolo.object_id
puts simbolo2.object_id
# 1.- cuando no necesito modificar el string
# 2.- cuando no necesito los metodos de string
# 3.- los simbolos se usan como nombres