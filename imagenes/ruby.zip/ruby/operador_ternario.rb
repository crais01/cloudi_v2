user = "chris"

if user == "chris"
	puts "tutor"
else
	puts "estudiante"
end

puts (if user == "chriss" then "tutor" else "visitante" end)

#operador ternario
#si_condicion_verdadero ? entonces_resultado : si_no_esto

puts user=="chris" ? "tutor" : "visitante"