i = 0
while i < 10
	puts  i
	i +=  1
end



playlist = ["cancion 1","cancion 2","cancion 3"]
playing =  true
index_song = 0

while (index_song < playlist.length) && playing
	puts "reproduciendo #{playlist[index_song]}"
	index_song += 1
#si da 0 hacemos stop
	print "coloca cero para detener la reproduccion :"
	respuesta = gets.chomp.to_i
	
	#if respuesta == 0
	#	playing = false
	#end

	playing = false if respuesta == 0

end


