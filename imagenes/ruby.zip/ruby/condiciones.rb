numero_uno = gets.chomp.to_i
numero_dos = gets.chomp.to_i

puts "numero uno : #{numero_uno}"
puts "numero dos : #{numero_dos}"

if numero_uno > numero_dos
	puts "numero uno es mayor al numero dos"
elsif numero_uno == numero_dos 
	puts "ambos numeros son iguales"
else
	puts "numero dos es menor a numero uno"
end

puts "numero uno es mayor al numero dos" if numero_uno > numero_dos

edad = gets.chomp.to_i

unless edad >= 18
	puts "no eres mayor de edad"
end

