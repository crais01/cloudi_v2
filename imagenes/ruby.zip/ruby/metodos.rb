def square(x)

	return 0 unless x.is_a? Integer

	x*x
end

def saludar
	puts "hola mundo"	
end

puts square(2)
saludar() 