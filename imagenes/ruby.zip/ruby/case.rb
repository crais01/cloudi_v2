print "dame tu calificacion : "
nota = gets.chomp.to_i

case nota
when 10
	puts "muy bien"
when 9
	puts "muy bien"
when 8
	puts "aun puedes mejorar"
when 7
	puts "sabemos que lo puedes hacer mejor"
when 6
	puts "csi horrible"
else
	puts "rip"
end

#segunda forma

puts case nota
when 10
	"muy bien"
when 9
	"muy bien"
when 8
	"aun puedes mejorar"
when 7
	"sabemos que lo puedes hacer mejor"
when 6
	"csi horrible"
else
	"rip"
end

# tercera forma
puts case nota
when 10,9
	"muy bien"
when 8
	"aun puedes mejorar"
when 7
	"sabemos que lo puedes hacer mejor"
when 6
	"csi horrible"
else
	"rip"
end