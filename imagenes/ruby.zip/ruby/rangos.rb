numero = (1..10)

numero.each do |num|
	puts num 
end

(1..10).each do |num|
	puts num
end


(1..10).step(2).each do |num|
	puts num
end
