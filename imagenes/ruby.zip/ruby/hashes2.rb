# operaciones de hashes

tutor = {
	"nombre"=>"christopher",
	"apellido"=>"cortes",
	"edad"=>29
}

puts tutor.length
#muestra arreglo con las llaves del hashes
puts tutor.keys

tutor.clean #limpia todo el hash
tutor.delete(:edad) ##eliminar un campo del arreglo
tutor.index("cortes") o tutor.key("cortes") # para traer el nombre de la clave
