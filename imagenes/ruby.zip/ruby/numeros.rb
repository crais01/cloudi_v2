puts 20 + 20
puts 10 / 3
puts 10.0 / 3.0
puts 10.to_f
puts 12.12131.to_i
