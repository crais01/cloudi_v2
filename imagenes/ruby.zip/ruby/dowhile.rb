numero = -1

begin
	numero = gets.chomp.to_i
end while numero < 0