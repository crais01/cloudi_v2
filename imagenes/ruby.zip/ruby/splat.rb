# def hola_gente(*personas) indica al metodo que todo lo que reciba sera transforme a un arreglo
def hola_gente(*personas)

	# otra forma de escribir el each
	# personas.each {|persona| puts "hola #{persona}"}
	personas.each do |persona|
		puts "hola #{persona}"
	end	
end

per = ["chris","cata"]

hola_gente(*per)