calificaciones = [10,7,8,9,6,8]

#suma = 0

#calificaciones.each do |calificacion|
#	puts "ahora la calificacion vale : #{calificacion}"
#end

#calificaciones.each_with_index do |calificacion,posicion|
#	puts "en la posicion #{posicion} tenemos la clasificacion : #{calificacion}"
#end

#calificaciones.each do |calificacion|
#	suma += calificacion.to_i
#end
# calificaciones.join("-") == calificaciones * "-"

puts calificaciones * "-"

#puts calificaciones.sort
puts calificaciones.reverse

puts calificaciones.include?(10)