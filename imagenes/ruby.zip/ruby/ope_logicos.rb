if (10 > 5) && (5 < 8)
	puts "entro"
end

if (10 > 5) || (5 < 8)
	puts "entro"
end

